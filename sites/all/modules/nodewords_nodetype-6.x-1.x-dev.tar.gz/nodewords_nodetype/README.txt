This module extends the functionality of Meta tags so a global default
"description" meta tag can be specified on a per node type basis.

It uses Token module allowing token replacements.

This module will probably not be ported to 6.x as nodewords 6.x.2.x will have
token support.

Dependencies

    * Meta tags
    * Token

INSTALLATION:

1) Place this module directory in your modules folder (this will usually be
"sites/all/modules/").

2) Enable the module.

3) You can configure Meta Tags on each content type' settings page.

Last updated:
------------
