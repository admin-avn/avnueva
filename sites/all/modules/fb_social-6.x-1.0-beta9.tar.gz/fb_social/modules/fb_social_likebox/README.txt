
-- Summary -- 

The "facebook social likebox" integrate the facebook's social likebox plugin in Drupal
(see http://developers.facebook.com/docs/reference/plugins/like-box). 


-- Requirements --

Requires the "facebook social" module which is included in this package


-- Installation -- 

* Install as usual, see http://drupal.org/node/70151 for further information.


-- CONFIGURATION -- 

* Administer > Site configuration > Facebook Social > likebox
* Enable "like box" block as any other drupal block

 
  
