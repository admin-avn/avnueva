
-- Summary --

The facebook social module contain common functions for supporting 
other modules in this package. 

-- Requirements --

Javascript capable browser


-- Installation 

* Install as usual, see http://drupal.org/node/70151 for further information.


-- Configuration

Administer › Site configuration > Facebook Social
